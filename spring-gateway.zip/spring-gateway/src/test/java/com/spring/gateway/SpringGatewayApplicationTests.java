package com.spring.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
