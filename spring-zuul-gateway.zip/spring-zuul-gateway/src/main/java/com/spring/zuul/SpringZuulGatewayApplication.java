package com.spring.zuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringZuulGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringZuulGatewayApplication.class, args);
	}

}
