package com.spring.zuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringZuulGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
